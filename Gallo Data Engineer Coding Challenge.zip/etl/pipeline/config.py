LOCATION = "http://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data"
COLUMNS = ["sepal length", "sepal width", "petal length", "petal width", "class"]
CSV_FILENAME = r"iris.csv"
PARQUET_FILENAME = r"iris.parquet"
PARAMS = None
RAW_FILE_PATH = r"C:\\Users\ajfon\\Documents\\Classes\\projects\\etl\\raw_files"
PARQUET_PATH = r"C:\\Users\\ajfon\\Documents\\Classes\\projects\\etl\\parquet"
